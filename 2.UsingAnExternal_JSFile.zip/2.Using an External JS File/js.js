// JavaScript File
var age=20;
var text=" years old";

alert(age+text);

